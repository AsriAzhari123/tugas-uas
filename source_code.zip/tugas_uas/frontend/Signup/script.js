document.querySelector("form").addEventListener("submit", function(event) {
    event.preventDefault();
  
    const username = document.querySelector("#username").value;
    const email = document.querySelector("#email").value;
    const password = document.querySelector("#password").value;
    const passwordConfirm = document.querySelector("#password-confirm").value;
  
    if (username === "") {
      alert("Username is required");
      return;
    }
  
    if (email === "") {
      alert("Email is required");
      return;
    }
  
    if (password === "") {
      alert("Password is required");
      return;
    }
  
    if (passwordConfirm === "") {
      alert("Confirm Password is required");
      return;
    }
  
    if (password !== passwordConfirm) {
      alert("Password and Confirm Password do not match");
      return;
    }
  
    alert("Sign Up successful!");
  });
  