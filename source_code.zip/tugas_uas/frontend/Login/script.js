// Simulasi data pengguna
const users = [
    { username: "user1", password: "password1" },
    { username: "user2", password: "password2" }
  ];
  
  const form = document.querySelector("form");
  form.addEventListener("submit", event => {
    event.preventDefault();
  
    const formData = new FormData(form);
    const username = formData.get("username");
    const password = formData.get("password");
  
    const user = users.find(
      user => user.username === username && user.password === password
    );
  
    if (user) {
      alert("Login berhasil");
    } else {
      alert("Login gagal");
    }
  });
  