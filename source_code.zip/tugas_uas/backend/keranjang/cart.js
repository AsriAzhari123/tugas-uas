fetch('http://localhost:3000/api',{
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    }
})
.then((res) => res.json())
.then((data) => {
    const content = document.getElementById('root')
    let i=0;
    data.map((item) => (
        item.barang.map((brg) =>{
            content.innerHTML +=
            `<div class="box">
                         <p>${item.toko}</p>
                         <div class="img-box">
                             <img class='images' src="${brg.image}" </img>
                         </div>
                         <div class="bottom">
                             <p class="nama-barang">${brg.nama}</p>
                             <h2>Rp. ${brg.harga}.00</h2>`+
                            "<button onclick='addtocart("+(i++)+")'>Add To Cart</button>"+
                        `</div>
                    </div>`
        })
    )).join('')
    
})

const cart = [];

function addtocart(a){
  fetch('http://localhost:3000/api',{
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    }
})
.then((res) => res.json())
.then((data) => {
    let i=0;
    data.map((item) => (
        item.barang.map((brg) =>{
            if(a==i){
              cart.push(brg);
            }
            i++;
        }
        )
    )).join('')
    displaycart();
})
}

function lert(){
  if (cart.length > 0) 
    alert("Terima Kasih Sudah Membayar");
  else{
    alert("Tidak ada barang Yang Dibeli");
  }
}

function del(a){
  cart.splice (a,100);
  displaycart();
}


function delElement(a){
  cart.splice(a,1);
  displaycart();
}

function displaycart(){
  let j = 0, total = 0;
  document.getElementById("count").innerHTML=cart.length;
  if(cart.length==0){
    document.getElementById('cartItem').innerHTML = "Your Cart is Empty";
    document.getElementById('total').innerHTML = "Rp."+0+".00";
  }
  else{
    document.getElementById('cartItem').innerHTML = cart.map((item) => 
    {
      const {image,nama,harga} = item;
      total=total+harga;
      document.getElementById('total').innerHTML = "Rp."+total+".00";
      return(
        `<div class='cart-item'>
        <div class='row-img'>
          <img class='rowimg' src=${image}>
        </div>
        <p style='font-size:12px;'>${nama}</p>
        <h2 style='font-size: 15px;'>Rp. ${harga}.00</h2>`+
        "<i class='bi bi-trash-fill' onclick='delElement("+(j++)+")'></i></div>"+
        `</div>`);
    }).join('');
  } 
}

// penjelasan:

// fetch itu untuk mengambil data dari database
// method GET untuk mengambil data
// method POST untuk menambahkan data
// method PUT untuk mengubah data
// method DELETE untuk menghapus data
// headers untuk menentukan tipe data yang akan diambil
// res.json() untuk mengubah data yang diambil menjadi json
// data.map untuk mengambil data dari json

// fungsi yang saya buat:
// 1. saya membuat fungsi addtocart untuk menambahkan barang ke dalam cart
// 2. fungsi displaycart untuk menampilkan barang yang ada di dalam cart
// 3. fungsi del untuk menghapus semua barang yang ada di dalam cart
// 4. fungsi delElement untuk menghapus barang yang dipilih di dalam cart
// 5. fungsi lert untuk menampilkan alert jika cart tidak kosong

// noted:
// Variabel i digunakan sebagai penghitung, diincrement setiap kali tombol diklik dan diteruskan sebagai argumen ke fungsi addtocart. Tujuan dari ini adalah untuk melacak tombol mana (atau item) yang diklik dan dengan demikian dapat digunakan dalam fungsi addtocart untuk melakukan tindakan yang sesuai, seperti menambahkan item ke keranjang belanja.
// Dalam kasus ini, fungsi addtocart dipanggil dan diteruskan sebagai argumen (i++). Ini berarti bahwa nilai i akan diteruskan sebagai argumen ke fungsi dan kemudian ditambah 1. Tujuan dari ini adalah untuk melacak tombol mana (atau item) yang diklik dan dengan demikian dapat digunakan dalam fungsi addtocart untuk melakukan tindakan yang sesuai, seperti menambahkan item ke keranjang belanja.

//  a itu adalah variabel yang digunakan untuk menampung data yang diambil dari database