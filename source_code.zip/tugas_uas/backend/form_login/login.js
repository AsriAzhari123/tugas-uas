// simulasi login
const login = (username, password) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
        const user = users.find(
            user => user.username === username && user.password === password
        );
    
        if (user) {
            resolve(user);
        } else {
            reject("Username atau password salah");
        }
        }, 1000);
    });
    }

// simulasi logout
const logout = () => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
        resolve();
        }, 1000);
    });
    }

// simulasi register
const register = (username, password) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
        const user = users.find(user => user.username === username);
    
        if (user) {
            reject("Username sudah digunakan");
        } else {
            users.push({ username, password });
            resolve();
        }
        }, 1000);
    });
    }

// simulasi ganti password
const changePassword = (username, password, newPassword) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
        const user = users.find(
            user => user.username === username && user.password === password
        );
    
        if (user) {
            user.password = newPassword;
            resolve();
        } else {
            reject("Username atau password salah");
        }
        }, 1000);
    });
    }
